<?php
session_start();
require_once 'koneksi.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$errors = [];
$editProduct = null;

/* CREATE, UPDATE, DELETE */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        http_response_code(403);
        exit('Token keamanan tidak valid. Muat ulang halaman.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
        if ($id && $id > 0) {
            $stmt = $pdo->prepare('DELETE FROM products WHERE id = :id');
            $stmt->execute(['id' => $id]);
        }
        header('Location: index.php?status=deleted');
        exit;
    }

    if ($action === 'save') {
        $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? 'Umum');
        $price = filter_var($_POST['price'] ?? '', FILTER_VALIDATE_FLOAT);
        $stock = filter_var($_POST['stock'] ?? '', FILTER_VALIDATE_INT);

        if (mb_strlen($name) < 3) $errors[] = 'Nama produk minimal 3 karakter.';
        if ($category === '') $category = 'Umum';
        if (mb_strlen($category) > 50) $errors[] = 'Kategori maksimal 50 karakter.';
        if ($price === false || $price <= 0) $errors[] = 'Harga harus lebih besar dari 0.';
        if ($stock === false || $stock < 0) $errors[] = 'Stok tidak boleh negatif.';

        if (!$errors) {
            try {
                if ($id && $id > 0) {
                    $stmt = $pdo->prepare(
                        'UPDATE products SET name=:name, category=:category, price=:price, stock=:stock WHERE id=:id'
                    );
                    $stmt->execute([
                        'name' => $name, 'category' => $category,
                        'price' => $price, 'stock' => $stock, 'id' => $id
                    ]);
                    header('Location: index.php?status=updated');
                } else {
                    $stmt = $pdo->prepare(
                        'INSERT INTO products (name, category, price, stock) VALUES (:name, :category, :price, :stock)'
                    );
                    $stmt->execute([
                        'name' => $name, 'category' => $category,
                        'price' => $price, 'stock' => $stock
                    ]);
                    header('Location: index.php?status=created');
                }
                exit;
            } catch (PDOException $e) {
                $errors[] = $e->getCode() === '23000'
                    ? 'Nama produk sudah digunakan.'
                    : 'Data gagal disimpan. Periksa database.';
            }
        }
    }
}

/* READ, SEARCH, FORM EDIT */
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);
if ($editId && $editId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = :id');
    $stmt->execute(['id' => $editId]);
    $editProduct = $stmt->fetch();
}

$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $stmt = $pdo->prepare(
        'SELECT * FROM products WHERE name LIKE :q OR category LIKE :q ORDER BY id DESC'
    );
    $stmt->execute(['q' => "%$q%"]);
} else {
    $stmt = $pdo->query('SELECT * FROM products ORDER BY id DESC');
}
$products = $stmt->fetchAll();

$statusMessages = [
    'created' => 'Produk berhasil ditambahkan.',
    'updated' => 'Produk berhasil diperbarui.',
    'deleted' => 'Produk berhasil dihapus.'
];
$status = $_GET['status'] ?? '';

$formName = $editProduct['name'] ?? ($_POST['name'] ?? '');
$formCategory = $editProduct['category'] ?? ($_POST['category'] ?? 'Umum');
$formPrice = $editProduct['price'] ?? ($_POST['price'] ?? '');
$formStock = $editProduct['stock'] ?? ($_POST['stock'] ?? '0');
$formId = $editProduct['id'] ?? ($_POST['id'] ?? '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Manager</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="hero">
    <div class="container">
        <p class="eyebrow">PEMROGRAMAN WEB • PERTEMUAN 3</p>
        <h1>📦 Product Manager</h1>
        <p>Kelola data produk dengan mudah.</p>
    </div>
</header>

<main class="container">
    <?php if (isset($statusMessages[$status])): ?>
        <p class="notice"><?= e($statusMessages[$status]) ?></p>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="error-box">
            <?php foreach ($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <section class="panel">
        <h2><?= $editProduct ? 'Edit Produk' : 'Tambah Produk' ?></h2>
        <form method="POST" action="index.php" class="product-form">
            <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= e($formId) ?>">

            <label for="name">Nama produk</label>
            <input id="name" name="name" minlength="3" maxlength="100" value="<?= e($formName) ?>" required>

            <label for="category">Kategori</label>
            <input id="category" name="category" maxlength="50" value="<?= e($formCategory) ?>" required>

            <label for="price">Harga (Rp)</label>
            <input id="price" name="price" type="number" min="0.01" step="0.01" value="<?= e($formPrice) ?>" required>

            <label for="stock">Stok</label>
            <input id="stock" name="stock" type="number" min="0" step="1" value="<?= e($formStock) ?>" required>

            <button class="button primary" type="submit"><?= $editProduct ? 'Simpan Perubahan' : 'Tambah Produk' ?></button>
            <?php if ($editProduct): ?><a class="button muted-button" href="index.php">Batal Edit</a><?php endif; ?>
        </form>
    </section>

    <section class="list-heading">
        <div>
            <h2>Daftar Produk</h2>
            <p class="muted"><?= count($products) ?> produk ditampilkan</p>
        </div>
        <form method="GET" action="index.php" class="search">
            <input type="search" name="q" placeholder="Cari produk..." value="<?= e($q) ?>">
            <button class="button secondary" type="submit">Cari</button>
        </form>
    </section>

    <?php if (!$products): ?>
        <section class="panel empty"><p>Belum ada produk atau produk tidak ditemukan.</p></section>
    <?php else: ?>
        <section class="products">
            <?php foreach ($products as $product): ?>
                <article class="product-card">
                    <span class="category"><?= e($product['category']) ?></span>
                    <h3><?= e($product['name']) ?></h3>
                    <p class="price">Rp <?= number_format((float)$product['price'], 0, ',', '.') ?></p>
                    <p class="muted">Stok: <?= (int)$product['stock'] ?></p>
                    <div class="actions">
                        <a class="button secondary" href="index.php?edit=<?= (int)$product['id'] ?>">Edit</a>
                        <form method="POST" action="index.php" onsubmit="return confirm('Yakin ingin menghapus produk ini?');">
                            <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$product['id'] ?>">
                            <button class="button danger" type="submit">Hapus</button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>
    <footer>Product Manager • PHP + MySQL</footer>
</main>
</body>
</html>
